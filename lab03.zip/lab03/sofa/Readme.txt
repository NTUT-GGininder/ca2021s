MikuMikuDance用モデル：ソファー  2013/05/06

JP-----------------------------------------------------------
この作品はクリエイティブ・コモンズ・ライセンス

 表示 - 非営利 2.1 日本 の下に提供されています。
このライセンスのコピーを見るためには、
http://creativecommons.org/licenses/by-nc/2.1/jp/
をご覧ください。

EN-----------------------------------------------------------
This work is licensed under the Creative Commons 
表示 - 非営利 3.0 非移植 License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/3.0/.

-------------------------------------------------------------
このデータの商用利用以外は問題ないということです。
(ニコニコ動画やYouTubeは非商用とみなします。)
商用で必要な場合は連絡ください。

改変・再配布もしていただいて構いませんが、テクスチャのみでの配布はご遠慮ください。
またこのデータを使って何か問題が発生しても一切責任は取りません。


製作 ろっし/ビリヤードP
mail: rossi.billi@gmail.com
nico: http://www.nicovideo.jp/user/4388648
